package com.uttarakhand.kisanseva2.model.uploadItem

data class Data(
    val item: Item
)