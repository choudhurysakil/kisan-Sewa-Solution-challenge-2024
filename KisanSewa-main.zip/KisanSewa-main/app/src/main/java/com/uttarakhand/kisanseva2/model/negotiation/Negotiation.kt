package com.uttarakhand.kisanseva2.model.negotiation

data class Negotiation(
    val `data`: List<Data>,
    val message: String
)