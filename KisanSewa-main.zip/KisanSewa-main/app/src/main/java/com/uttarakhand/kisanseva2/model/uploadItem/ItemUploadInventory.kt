package com.uttarakhand.kisanseva2.model.uploadItem

data class ItemUploadInventory(
    val `data`: Data,
    val message: String
)