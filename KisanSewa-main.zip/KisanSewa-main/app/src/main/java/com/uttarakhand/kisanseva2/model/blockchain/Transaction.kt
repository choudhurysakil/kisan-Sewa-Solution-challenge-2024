package com.uttarakhand.kisanseva2.model.blockchain

data class Transaction(
    val amount: String,
    val bank: String,
    val credit_score: String,
    val farmer: String
)