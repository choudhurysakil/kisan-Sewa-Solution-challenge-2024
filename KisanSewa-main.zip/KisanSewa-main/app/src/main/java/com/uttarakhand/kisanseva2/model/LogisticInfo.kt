package com.uttarakhand.kisanseva2.model


class LogisticInfo(var name: String, var link: String, var description: String) {
    var isExpanded = false
}