package com.uttarakhand.kisanseva2.model;

/**
 * Created by sukhbir on 20/8/16.
 */
public class ItemHealthCard {
    private String id,name;
    private String background;

    public String getBackground() {
        return background;
    }

    public void setBackground(String background) {
        this.background = background;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
