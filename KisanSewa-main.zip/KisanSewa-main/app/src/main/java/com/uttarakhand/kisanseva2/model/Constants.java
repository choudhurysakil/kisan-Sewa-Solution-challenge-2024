package com.uttarakhand.kisanseva2.model;

public class Constants {
    public static final String PHONE_NUMBER = "phoneNumber";
}
