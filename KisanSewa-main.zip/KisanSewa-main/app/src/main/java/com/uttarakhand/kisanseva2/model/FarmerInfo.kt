package com.uttarakhand.kisanseva2.model

data class FarmerInfo(
    val `data`: Data,
    val message: String
)