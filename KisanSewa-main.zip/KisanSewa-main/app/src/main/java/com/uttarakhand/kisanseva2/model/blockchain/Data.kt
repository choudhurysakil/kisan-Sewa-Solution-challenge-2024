package com.uttarakhand.kisanseva2.model.blockchain

data class Data(
    val __v: Int,
    val _id: String,
    val `data`: DataX
)