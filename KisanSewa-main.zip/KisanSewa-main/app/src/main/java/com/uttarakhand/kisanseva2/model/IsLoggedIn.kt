package com.uttarakhand.kisanseva2.model

data class IsLoggedIn(
    val message: String,
    val user: User
)