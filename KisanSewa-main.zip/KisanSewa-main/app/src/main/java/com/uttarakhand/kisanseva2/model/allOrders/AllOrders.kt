package com.uttarakhand.kisanseva2.model.allOrders

data class AllOrders(
    val `data`: List<Data>,
    val message: String
)