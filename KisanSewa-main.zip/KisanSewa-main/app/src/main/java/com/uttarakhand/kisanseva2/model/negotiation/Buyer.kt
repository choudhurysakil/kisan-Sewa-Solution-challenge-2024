package com.uttarakhand.kisanseva2.model.negotiation

data class Buyer(
    val address: String,
    val first_name: String,
    val phone: String
)