package com.uttarakhand.kisanseva2.model.blockchain

data class BlockchainResponse(
    val `data`: List<Data>,
    val message: String
)